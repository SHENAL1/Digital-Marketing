<?php 

/**
 * Custom widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */

/**
 * Load Custom Widget
 */
include_once( IMROZ_ADDONS_DIR. '/include/widgets/recent-posts.php' );
include_once( IMROZ_ADDONS_DIR. '/include/widgets/about-widget.php' );